
/**
 * Esta classe contém todos os dados necessários em uma pessoa que será do Tipo Aluno.
 * Na hierarquia, aluno é um filho de Pessoa e alguns de seus métodos e variáveis poderão
 * vir de sua classe pai.
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class Aluno extends Pessoa
{
    private int ra;
    private int serie;
    Disciplina discs[];
    
    /**
     * Aluno Construtor
     * Este construtor irá conter todos os dados necessários básicos para o aluno que serão
     * adicionados posteriormente, é o responsável por criar o objeto em memória.
     */
    Aluno(){
        setRa(0);
        setSerie(0);
        discs = new Disciplina[10];
    }
    
    //getters
    /**
     * Método getRa
     *
     * @return O valor de retorno será o RA daquele aluno específico
     */
    public int getRa(){
        return this.ra; 
    }

    /**
     * Método getSerie
     *
     * @return O valor de retorno será a série daquele aluno específico
     */
    public int getSerie(){
        return this.serie;
    } 
    
    //setters
    /**
     * Método setRa
     *
     * @param ra Um parâmetro do tipo String que conterá o RA
     * @return O valor de retorno será o ra que foi inserido
     */
    public void setRa(int  ra){
        this.ra = ra;   
    }

    /**
     * Método setSerie
     *
     * @param serie Um parâmetro do tipo String que conterá a série
     * @return O valor de retorno será a série que foi inserida
     */
    public void setSerie(int serie){
        this.serie = serie;
    }

    public void cadNovo(String  nome,int idade,int ra, int serie){
        criarPessoa(nome);
        setIdade(idade);
        setRa(ra);
        setSerie(serie);
    }

    /**
     * Método cadDisc
     *
     * @param disc Um parâmetro do tipo String que conterá as disciplinas
     * @param n Um parâmetro do tipo int que irá definir a quantidade de disciplinas a serem adicionadas
     * @param nota Um parâmetro do tipo float que conterá todas as notas das disciplinas que foram inseridads.
     */
    public void cadDisc(String[] nomedisc,float[] notadisc){
        int n = 0;
        while(n != -1){
            discs[n] = new Disciplina();
            discs[n].criaDisc(nomedisc[n]);
            discs[n].setNota(notadisc[n]);
            n++;
            if(nomedisc[n] == null){
                n = -1;
            }
            if(n > 8){
                n = -1;
            } 
        }
    } 

    /**
     * Método getDisc
     *
     * @param n Um parâmetro do tipo inteiro que será a posição da disciplina em questão
     * @return O valor de retorno será o nome da disciplina que se quer o nome
     */
    public  String mostraNomeDisc(int n){
        if(discs[n] != null){ 
            return discs[n].getNomeDisc();
        }
        return ""; 
    } 

    /**
     * Método mostraNotaDisc
     *
     * @param n Um parâmetro do tipo inteiro que será a posição do array que está aquele matéria
     * @return O valor de retorno de acordo com a matéria desejada em n e sua respectiva nota
     */
    public float mostraNotaDisc(int n){
        if(discs[n] != null){ 
            return discs[n].getNota();
        }
        return -1; 
    }
}
