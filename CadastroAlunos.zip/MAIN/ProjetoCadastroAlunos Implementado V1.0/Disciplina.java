
/**
 * Esta classe conterá todas as funcionalidades básicas para o funcionamento do cadastro de disciplinas
 * de um aluno, os métodos mais importantes relacionados a este tema encontram-se aqui
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class Disciplina
{
    private float nota;
    Texto nomedisc;
    
    /**
     * Disciplina Construtor
     * Este construtor irá conter todos os dados necessários básicos para a disciplina do aluno que serão
     * adicionados posteriormente, é o responsável por criar o objeto em memória.
     */
    Disciplina(){
        criaDisc("Vazio");
        setNota(0);
    }
    
    /**
     * Método criaDisc
     * Este método permite que você cadastre uma nova disciplina de acordo com o nome que for inserido
     *
     * @param nomedisc Um parâmetro do tipo String que irá conter o nome da disciplina que se deseja ser cadastrada
     */
    public void criaDisc(String nomedisc){
        setDisc(new Texto(nomedisc));
    }
    
    /**
     * Método setDisc
     * Este método permite que você defina uma nova disciplina de acordo com o nome que for inserido
     *
     * @param nomedisc Um parâmetro do tipo Texto que contém o nome da Disciplina que será cadastrada
     */
    public void setDisc(Texto nomedisc){
        this.nomedisc = nomedisc;
    }
    
    /**
     * Método setNota
     * Este método permite que você defina uma nota de acordo com o valor que for inserido
     *
     * @param nota Um parâmetro do tipo float que contém a nota que foi inserida
     */
    public void setNota(float nota){
        this.nota = nota;
    }
    
    /**
     * Método getNomeDisc
     * Este método permite que o nome da disciplina seja exibido da forma que for desejada
     *
     * @return O valor de retorno poderá ser de duas maneiras. I) Vazio caso não corresponda a nenhuma disciplina cadastrada. II) O nome correto da disciplina formatada corretamente no formato String
     */
    public String getNomeDisc(){
        if(nomedisc == null){
            return "";
        }
        return nomedisc.toString();
    }
    
    /**
     * Método getNota
     * Este método permite que a nota da disciplina seja exibido da forma que for desejada
     *
     * @return O valor de retorno irá exibir a nota de alguma disciplina que for requisitada
     */
    public float getNota(){
        return nota;
    }
}
   

