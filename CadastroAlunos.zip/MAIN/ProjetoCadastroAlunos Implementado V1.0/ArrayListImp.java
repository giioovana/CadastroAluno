import javax.swing.*;
import java.util.ArrayList;
import java.util.*;

/**
 * Esta classe contém todas as funcionalidades básicas relacionadas ao cadastro de alunos no
 * método de armazenamento em ArrayList.
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class ArrayListImp implements IArmazenador
{    
    private boolean error = false;
    public String nome;
    public String ra;
    public String serie;
    public String idade;
    public int id = 0;
    
    //Criação da array de alunos e professores para funcionalidade de cadastro em Array
    List<List<Object>> usuariosArr = new ArrayList<List<Object>>();
    List<Object> listaCad = new ArrayList<>();
    
    /**
     * Método getError
     * Este método tem como função mostrar qual foi o erro que foi encontrado ao decorrer de algum processo
     * do cadastro de informações
     *
     * @return O valor de retorno será o erro que foi encontrado em algum processo
     */
    public boolean getError(){
        return this.error;
    }
    
    /**
     * Método setError
     * Este tem como função capturar um erro que foi adquirido ao decorrer de algum processo
     * do cadastro de informações
     *
     * @param erro Um parâmetro
     */
    public void setError(boolean erro){
        this.error = erro;
    }
    
    /**
     * Método adicionarUsuarioAlunoArrayList
     * Este tem como função fazer o cadastro principal de todas as informações do aluno em uma List que
     * será armazenada dentro de uma ArrayList e armazenar seus respectivos valores em seus respectivos campos
     *
     * @param aluno Um parâmetro que terá todas as informações do aluno já inclusas no objeto
     */
    public void adicionar(Object a){ 
        //Criando a funcionalidade do ArrayList
        usuariosArr.add(listaCad);
        
        id++;
        
        listaCad.add(id);
        listaCad.add(a);
    }

    /**
     * Método buscarUsuarioArrayList
     * Este tem como função buscar um usuário na ArrayList que contém o ra desejado
     *
     * @param ra Um parâmetro do tipo String que contém o ra que foi solicitada a busca
     */
    public Object buscar (int i){
        try{
            return listaCad.contains(i);
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
            return null;
        }
    }

    /**
     * Método estaVaziaArrayList
     * Este tem como função verificar se a lista da ArrayList encontra-se vazia ou se contém alunos cadastrados
     *
     * @return O valor de retorno será a informação em formato de true ou false referente a veracidade do fato
     * de a lista estar vazia ou não
     */
    public boolean estaVazia(){
        boolean vazia = false;

        if(usuariosArr.isEmpty()){
            vazia = true;
        }else{        
            vazia = false;
        }
        
        return vazia;
    }

    /**
     * Método removerUsuarioArrayList
     * Este tem como função remover um usuário da ArrayList de acordo com o RA que foi selecionado
     * para ter as informações removidas
     *
     * @param ra Um parâmetro do tipo String que contém o RA que será removido junto com as demais informações
     */
    public Object remover(int i){
        int posicao;
        
        posicao = listaCad.indexOf(i);
        posicao++;
        usuariosArr.remove(posicao);
        
        return null;
    }
    
    /**
     * Método listarUsuarioArrayList
     * Este tem como objetivo dar o número total de usuários que estão cadastrados dentro da ArrayList
     */
    public int getQtd(){
        return usuariosArr.size();
    }
}

