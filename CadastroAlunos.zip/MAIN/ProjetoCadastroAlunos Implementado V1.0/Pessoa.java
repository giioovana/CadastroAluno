
/**
 * Escreva uma descrição da classe Pessoa aqui.
 * 
 * @author Pedro 
 * @version 2023
 */
public class Pessoa
{
    private int idade;
    private NomePessoa nome;
    
    /**
     * Método getIdade
     *
     * @return O valor de retorno da idade que foi setado de alguma forma, seja diretamente
     * ou indiretamente
     */
    public int getIdade(){
        return this.idade;
    }
    
    /**
     * Método getNome
     *
     * @return O valor de retorno será o nome transformado em String, para que não haja erros
     * como caracteres indesejados dentro do nome
     */
    public String getNome(){
        return nome.toString();
    }
    
    /**
     * Método criarPessoa
     *
     * @param nome recebe um nome do tipo String
     * Este método cria uma nova pessoa de acordo com o nome dela
     */
    public void criarPessoa(String nome){
        setNome(new NomePessoa(nome));
    }
    
    /**
     * Método setNome
     *
     * @param nome do tipo NomePessoa
     * Este método dá a possibilidade de um nome ser definido/capturado para uso posterior
     */
    public void setNome(NomePessoa nome){
        this.nome = nome;
    }
    
    /**
     * Método setIdade
     *
     * @param idade Um parâmetro do tipo inteiro que será recebido em alguma parte do código
     * Este método permite que o usuário defina a idade para alguma pessoa que está sendo cadastrada no momento
     */
    public void setIdade(int idade){
        this.idade = idade;
    }
    
}
