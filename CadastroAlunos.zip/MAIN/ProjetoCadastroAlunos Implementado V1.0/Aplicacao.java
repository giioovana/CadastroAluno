
/**
 * Escreva uma descrição da classe Aplicacao aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Aplicacao{ 
    public static void main(String args[]) { 

        
        IMenu ent = new EntradaGUI("aaaaa");
        ent.Menu();
        
        System.out.println("================== INICIO DO PROGRAMA ==================");
                
}
}
