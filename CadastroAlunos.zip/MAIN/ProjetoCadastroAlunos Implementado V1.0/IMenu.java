
/**
 * Escreva a descrição da interface IMenu aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface IMenu
{
   public int lerRa();
   public String lerNome();
   public float lerNotaDisc(int x);
   public int lerIdade();
   public int lerSerie();
   public void CriaMenuListar();
   public void Menu();
}
