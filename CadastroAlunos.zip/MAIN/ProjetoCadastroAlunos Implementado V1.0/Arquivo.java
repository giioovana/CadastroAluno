import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Esta classe contém todo o funcionamento básico para o salvamento em arquivo externo
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class Arquivo
{
    //Pegando o arquivo de impressão (ATENÇÃO: Em caso de mal funcionamento da impressão, edite o caminho do arquivo descrito abaixo
    final static String listaCadastrados = "./listaalunos.txt";
    
    /**
     * Método salvarDados
     * Este método permite que um arquivo externo localizado no endereço desejado seja lido e escrito,
     * permitindo assim a persistência em arquivo dos dados cadastrados
     *
     * @param alunoObj Um parâmetro do tipo Objeto que irá conter todas as informações cadastrais do aluno e que será inserida no arquivo final
     */
    public static void salvarDados(Object alunoObj){
        try {
            //Escreve no arquivo dentro do estado atual
            FileOutputStream arquivo = new FileOutputStream(new File(listaCadastrados));
            ObjectOutputStream objetoOut = new ObjectOutputStream(arquivo);

            objetoOut.writeObject(alunoObj);
            arquivo.flush();
                
            //Fecha obrigatoriamente o arquivo por segurança
            objetoOut.close();
            arquivo.close();
        } catch (FileNotFoundException e) { //Caso não encontre o arquivo
            System.out.println("O arquivo não pode ser encontrado, verifique as permissões e o diretório");
        } catch (IOException e) {
            System.out.println("Erro ao inicializar o arquivo");
        }
    }
    
    /**
     * Método lerDados
     * Este método permite que o arquivo atual seja lido
     */
    public void lerDados(){
        try {
            //Lê o arquivo no estado atual
            FileInputStream arquivoLer = new FileInputStream(new File(listaCadastrados));
            ObjectInputStream objetoLer = new ObjectInputStream(arquivoLer);
            
            objetoLer.read();
            
            //Fecha obrigatoriamente o arquivo por segurança
            objetoLer.close();
            arquivoLer.close();
        } catch (FileNotFoundException e) { //Caso não encontre o arquivo
            System.out.println("O arquivo não pode ser encontrado, verifique as permissões e o diretório");
        } catch (IOException e) {
            System.out.println("Erro ao inicializar o arquivo");
        }
    }
}
