
/**
 * Esta classe será a responsável por fazer o funcionamento principal do cadastro de todos 
 * os alunos da instituição, aqui estão os principais métodos e construtores. 
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class CadastroAlunos
{
    IArmazenador arm = new VetDin();
    //IArmazenador arm = new ArrayList();
    //IArmazenador arm = new ListaLigadaSimples();
    Arquivo arq = new Arquivo();
    Aluno aluno;
    
    /**
     * CadastroAlunos Construtor
     * Aqui armazenará todos os alunos que forem cadastrados, sendo o limite máximo
     * atualmente definido como 100 alunos.
     */
    CadastroAlunos (){
    }
    
    /**
     * Método Cadastro o qual será responsável por cadastrar definitivamente os dados
     * recebidos de um aluno em sua ficha de informações
     *
     * @param nome Um parâmetro do tipo String que conterá o nome inserido
     * @param idade Um parâmetro do tipo inteiro que conterá a idade inserida
     * @param serie Um parâmetro do tipo String que conterá a série inserida
     * @param ra Um parâmetro do tipo String que conterá o RA inserido
     */
    public void Cadastro(String nome,int idade,int ra,int serie){   
            aluno = new Aluno();
            aluno.cadNovo(nome,idade,ra,serie);
    }
    
    /**
     * Método getDisc
     * Este método retorna a disciplina do aluno em questão que está sendo requisitado
     *
     * @param posaluno Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter as disciplinas
     * @param posdisc Um parâmetro do tipo inteiro que é a posição respectiva da disciplina que se deseja ter as informações
     * @return O valor de retorno trará todas as informações requisitadas da disciplina em questão
     */
    public void cadDisc(String[] nomedisc,float[] notadisc){
            aluno.cadDisc(nomedisc,notadisc);
            Armazenar();
    }
    
    /**
     * Armazena o objeto em um arquivo extetrno
     */
    public void Armazenar(){
        arm.adicionar(aluno);
        Arquivo.salvarDados(aluno);
    }
    
    /**
     * Método mostraAlunos
     * Este método tem como objetivo listar todos os alunos que já foram cadastrados de acordo com o RA que for solicitado/inserido
     *
     * @param listara Um parâmetro do tipo String que conterá o RA solicitado para exibir as informações
     */
    public void mostraAluno(int ra,int qntDisc){
        int n = 0;int k = 0;
        System.out.println(ra);
        boolean alunoExiste = false;
        Aluno aux = (Aluno) arm.buscar(n); 
        while(arm.buscar(n) != null){
            aux = (Aluno) arm.buscar(n);
            if(aux.getRa() == ra){
                alunoExiste = true;
                System.out.println("Nome do aluno: " + aux.getNome()); 
                System.out.println("Idade do aluno: " + aux.getIdade());
                System.out.println("ra do aluno: " + aux.getRa());
                System.out.println("Serie do aluno: " + aux.getSerie());
                while(aluno.mostraNomeDisc(k) != null){
                    System.out.println("Nome disciplina" + aluno.mostraNomeDisc(k));
                    System.out.println("Nota disciplina" + aluno.mostraNotaDisc(k));
                    k++;
                    if(k >= qntDisc){
                        break;
                    }
                }
            }
            n++;
        }
        if (alunoExiste == false){
            System.out.println("Nao ha usuarios cadastrados com tal RA!");
        }
    }
}    
    

